#ifndef __TASK
#define __TASK
#include <algorithm>
#include <fstream>
#include <iostream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

using namespace std;
void GetInfo(string inputName, vector<vector<int>>& commCostMatrix,vector<string>& tasks);
#endif
